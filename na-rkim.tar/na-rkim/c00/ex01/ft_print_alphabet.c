/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: na-rkim <na-rkim@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/30 10:46:58 by na-rkim           #+#    #+#             */
/*   Updated: 2021/03/30 11:38:08 by na-rkim          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_alphabet(char alpha)
{
	while (alpha <= 'z')
	{
		write(1, &alpha, 1);
		++alpha;
	}
}

int		main(void)
{
	ft_print_alphabet('a');
	return (0);
}
