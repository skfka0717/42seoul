/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: na-rkim <na-rkim@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/30 13:28:28 by na-rkim           #+#    #+#             */
/*   Updated: 2021/03/30 15:48:57 by na-rkim          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char alpha)
{
	write(1, &alpha, 1);
}

void	ft_print_comb2(void)
{
	int a;
	int b;

	a = 0 - 1;
	while (++a <= 98)
	{
		b = a;
		while (++b <= 99)
		{
			ft_putchar(a / 10 + 48);
			ft_putchar(a % 10 + 48);
			write(1, " ", 2);
			ft_putchar(b / 10 + 48);
			ft_putchar(b % 10 + 48);
			if (a == 98 && b == 99)
				return ;
			write(1, ", ", 2);
		}
	}
}

int		main(void)
{
	ft_print_comb2();
	return (0);
}
