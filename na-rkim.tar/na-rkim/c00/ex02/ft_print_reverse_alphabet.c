/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: na-rkim <na-rkim@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/30 11:42:02 by na-rkim           #+#    #+#             */
/*   Updated: 2021/03/30 11:43:22 by na-rkim          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_alphabet(char alpha)
{
	while (alpha >= 'a')
	{
		write(1, &alpha, 1);
		--alpha;
	}
}

int		main(void)
{
	ft_print_alphabet('z');
	return (0);
}
