/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr(망).c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: na-rkim <na-rkim@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/30 15:51:26 by na-rkim           #+#    #+#             */
/*   Updated: 2021/03/30 20:14:14 by na-rkim          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char alpha)
{
	write(1, &alpha, 1);
}

void	divcount(int num)
{
	int count;
	count = 10;

	while (num / 10 != 0)
	{
	num /= 10;
	count += 1;
	}
	return count;
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
		write(1, "–2147483648", 11);
	else if (nb < 0)
		nb *= -1;
	int count;
	count = divcount(nb);
	while (count != 0)
	{
		ft_putchar(nb % 10 + 48);
		nb /= 10;
		--count;
	}
}

int		main(void)
{
	ft_putnbr(1234);
	return (0);
}
