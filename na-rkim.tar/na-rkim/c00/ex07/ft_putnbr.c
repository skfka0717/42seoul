#include <unistd.h>

void    putchar(char alpha)
{
    write(1, &alpha, 1); 
}

void	numberofdigits(int num)
{
	int count;
	count = 0;

	while (num/10 != 0)
	{

	}
		
}

void    ft_putnbr(int nb) 
{   
    int copynb;
    copynb = nb; 

    if (copynb == -2147483647)
        write(1, "-2147483647", 11);
    else if (copynb < 0)
        copynb *= -1; 
    while (nb / 10 != 0)
    {   
        while (copynb / 10 != 0)

        {   
            copynb /= 10; 
        }   
        putchar( copynb % 10 + 48 );
        nb /= 10; 
    }   
}

int     main(void)
{
    ft_putnbr(2345);
    return (0);
}
