/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: na-rkim <na-rkim@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/30 18:20:56 by na-rkim           #+#    #+#             */
/*   Updated: 2021/03/30 22:16:02 by na-rkim          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	putchar(char alpha)
{
	write(1, &alpha, 1);
}

void	ft_putnbr(int nb)
{	
	int copynb;
	copynb = nb;

	if (copynb == -2147483647)
		write(1, "-2147483647", 11);
	else if (copynb < 0)
		copynb *= -1;
	while (nb / 10 != 0)
	{
		while (copynb / 10 != 0)

		{
			copynb /= 10;
		}
		putchar( copynb % 10 + 48 );
		nb /= 10;
	}
}

int		main(void)
{
	ft_putnbr(2345);
	return (0);
}
