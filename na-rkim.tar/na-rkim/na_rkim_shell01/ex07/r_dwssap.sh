#! \bin\bash
cat /etc/passwd | grep -v '^#' | awk 'NR%2==0' | cut -d ':' -f 1 | rev | sort -r | sed -n -e "${FT_LINE1},${FT_LINE2}"'p' | sed 's/_/_,/g' | tr '\n' ' ' | sed 's/, $/./g' | tr -d '\n'
