#! \bin\bash
id -Gn | sed "s/ /,/g" | tr -d '\n'
